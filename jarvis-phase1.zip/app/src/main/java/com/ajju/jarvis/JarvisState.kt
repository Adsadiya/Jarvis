package com.ajju.jarvis

import android.graphics.Color

enum class JarvisState(val label: String, val color: Int) {
    IDLE("IDLE", Color.parseColor("#00B8D4")),
    LISTENING("LISTENING", Color.parseColor("#00E676")),
    THINKING("THINKING", Color.parseColor("#FFAB00")),
    SPEAKING("SPEAKING", Color.parseColor("#7C4DFF")),
    ERROR("ERROR", Color.parseColor("#FF1744"))
}
