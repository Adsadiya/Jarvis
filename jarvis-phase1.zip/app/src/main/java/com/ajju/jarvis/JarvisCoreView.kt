package com.ajju.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class JarvisCoreView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: JarvisState = JarvisState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private var t = 0f
    private val twoPi = (2 * PI).toFloat()

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 5f
    }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    fun startAnimation() {
        if (!animator.isRunning) animator.start()
    }

    fun stopAnimation() {
        animator.cancel()
    }

    private fun alpha(color: Int, a: Int) =
        Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val color = state.color
        val base = min(width, height) * 0.2f

        val pulse = when (state) {
            JarvisState.SPEAKING -> 1f + 0.12f * sin(t * twoPi * 4)
            JarvisState.THINKING -> 1f + 0.05f * sin(t * twoPi * 2)
            JarvisState.LISTENING -> 1f + 0.04f * sin(t * twoPi * 2)
            else -> 1f + 0.03f * sin(t * twoPi)
        }
        val r = base * pulse

        // Outer glow
        glowPaint.shader = RadialGradient(
            cx, cy, r * 2.2f,
            intArrayOf(alpha(color, 150), alpha(color, 40), Color.TRANSPARENT),
            floatArrayOf(0.3f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 2.2f, glowPaint)

        // Core
        corePaint.shader = RadialGradient(
            cx, cy, r * 0.6f,
            intArrayOf(Color.WHITE, color, alpha(color, 200)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 0.6f, corePaint)

        // Rotating rings (integer multiples of 360 so the loop is seamless)
        val speed = if (state == JarvisState.THINKING) 3f else 1f
        for (i in 0..2) {
            val rr = r * (1.2f + 0.3f * i)
            ringPaint.strokeWidth = 7f - i * 1.5f
            ringPaint.color = alpha(color, 230 - i * 55)
            val dir = if (i % 2 == 0) 1 else -1
            val start = dir * t * 360f * speed * (i + 1)
            canvas.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, start, 100f + i * 40f, false, ringPaint)
        }

        // Waveform bars while listening / speaking
        if (state == JarvisState.LISTENING || state == JarvisState.SPEAKING) {
            val count = 48
            val maxLen = if (state == JarvisState.LISTENING) r * 0.5f else r * 0.3f
            barPaint.color = alpha(color, 210)
            for (i in 0 until count) {
                val ang = i * twoPi / count
                val amp = 0.5f + 0.5f * sin(t * twoPi * 3 + i * 0.7f)
                val len = 6f + maxLen * amp
                val r0 = r * 1.95f
                val r1 = r0 + len
                canvas.drawLine(
                    cx + cos(ang) * r0, cy + sin(ang) * r0,
                    cx + cos(ang) * r1, cy + sin(ang) * r1,
                    barPaint
                )
            }
        }
    }
}
