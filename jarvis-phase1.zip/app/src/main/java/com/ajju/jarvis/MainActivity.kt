package com.ajju.jarvis

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var core: JarvisCoreView
    private lateinit var tvStatus: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvMic: TextView
    private lateinit var tvNet: TextView
    private lateinit var tvLast: TextView
    private lateinit var tvReply: TextView

    private val states = JarvisState.values()
    private var index = 0

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = updateBattery(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        core = findViewById(R.id.core)
        tvStatus = findViewById(R.id.tvStatus)
        tvBattery = findViewById(R.id.tvBattery)
        tvMic = findViewById(R.id.tvMic)
        tvNet = findViewById(R.id.tvNet)
        tvLast = findViewById(R.id.tvLast)
        tvReply = findViewById(R.id.tvReply)

        // Phase 1 has no microphone access at all.
        tvMic.text = "MIC ○ OFF"

        // Tap the core to preview every state (temporary, until voice is wired in).
        core.setOnClickListener {
            index = (index + 1) % states.size
            setState(states[index])
            updateNetwork()
        }
        setState(JarvisState.IDLE)
    }

    override fun onStart() {
        super.onStart()
        val sticky = ContextCompat.registerReceiver(
            this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { updateBattery(it) }
        updateNetwork()
        core.startAnimation()
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(batteryReceiver)
        core.stopAnimation()
    }

    private fun setState(s: JarvisState) {
        core.state = s
        tvStatus.text = "JARVIS • ${s.label}"
        tvStatus.setTextColor(s.color)
        when (s) {
            JarvisState.SPEAKING -> {
                tvLast.text = "Last command: (demo) battery kitni hai?"
                tvReply.text = "(demo) Battery 68 प्रतिशत है।"
            }
            JarvisState.ERROR -> tvReply.text = "माफ़ कीजिए, Android ने इस action की अनुमति नहीं दी।"
            JarvisState.IDLE -> {
                tvLast.text = "Last command: —"
                tvReply.text = "जी सर, बताइए।"
            }
            else -> Unit
        }
    }

    private fun updateBattery(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        tvBattery.text = "BATTERY $pct%" + if (charging) " ⚡" else ""
        tvBattery.setTextColor(if (pct <= 15 && !charging) Color.parseColor("#FF1744") else Color.parseColor("#B0BEC5"))
    }

    private fun updateNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        tvNet.text = if (online) "NET ● ONLINE" else "NET ○ OFFLINE"
    }
}
